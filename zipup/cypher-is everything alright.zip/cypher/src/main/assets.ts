import { app, dialog, protocol } from 'electron'
import { join, resolve, extname } from 'node:path'
import { readFile } from 'node:fs/promises'
import { copyFileSync, mkdirSync } from 'node:fs'
import { randomUUID } from 'node:crypto'

/**
 * Local asset handling. User-chosen images (book covers now, character images
 * later) are copied into the app-data "assets" folder so the library is fully
 * self-contained and portable. They are served to the renderer through a
 * private custom protocol rather than raw file:// paths.
 *
 *   stored ref (in DB):  "covers/<uuid>.png"
 *   renderer URL:        "cypher-asset://local/covers/<uuid>.png"
 */
const SCHEME = 'cypher-asset'

export function assetsRoot(): string {
  return join(app.getPath('userData'), 'assets')
}

/** Absolute on-disk path for a stored asset ref (e.g. "reader/x.epub"). */
export function absoluteAssetPath(rel: string): string {
  return resolve(assetsRoot(), rel)
}

const MIME: Record<string, string> = {
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.gif': 'image/gif',
  // Fonts: served through the same protocol so the personal script can be
  // swapped in at any time. A generic octet-stream type makes some engines
  // refuse the @font-face, so these are declared explicitly.
  '.ttf': 'font/ttf',
  '.otf': 'font/otf',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2'
}

/** Must run BEFORE app is ready. */
export function registerAssetSchemePrivileged(): void {
  protocol.registerSchemesAsPrivileged([
    {
      scheme: SCHEME,
      privileges: { standard: true, secure: true, supportFetchAPI: true, stream: true }
    }
  ])
}

/** Must run AFTER app is ready. */
export function registerAssetProtocol(): void {
  protocol.handle(SCHEME, async (request) => {
    const url = new URL(request.url)
    const rel = decodeURIComponent(url.pathname).replace(/^\/+/, '')
    const root = resolve(assetsRoot())
    const filePath = resolve(root, rel)
    if (!filePath.startsWith(root)) {
      return new Response('Forbidden', { status: 403 })
    }
    try {
      const data = await readFile(filePath)
      const type = MIME[extname(filePath).toLowerCase()] ?? 'application/octet-stream'
      return new Response(new Uint8Array(data), { headers: { 'Content-Type': type } })
    } catch {
      return new Response('Not found', { status: 404 })
    }
  })
}

/** Opens a file picker, copies the chosen image into app-data, returns its ref. */
export async function importCover(): Promise<string | null> {
  const result = await dialog.showOpenDialog({
    title: 'Choose a cover image',
    properties: ['openFile'],
    filters: [{ name: 'Images', extensions: ['png', 'jpg', 'jpeg', 'webp', 'gif'] }]
  })
  if (result.canceled || result.filePaths.length === 0) return null

  const src = result.filePaths[0]
  const dir = join(assetsRoot(), 'covers')
  mkdirSync(dir, { recursive: true })
  const ext = extname(src).toLowerCase() || '.png'
  const name = `${randomUUID()}${ext}`
  copyFileSync(src, join(dir, name))
  return `covers/${name}`
}

/** Opens a file picker, copies the chosen image into app-data, returns its ref. */
export async function importCharacterImage(): Promise<string | null> {
  const result = await dialog.showOpenDialog({
    title: 'Choose a character image',
    properties: ['openFile'],
    filters: [{ name: 'Images', extensions: ['png', 'jpg', 'jpeg', 'webp', 'gif'] }]
  })
  if (result.canceled || result.filePaths.length === 0) return null

  const src = result.filePaths[0]
  const dir = join(assetsRoot(), 'characters')
  mkdirSync(dir, { recursive: true })
  const ext = extname(src).toLowerCase() || '.png'
  const name = `${randomUUID()}${ext}`
  copyFileSync(src, join(dir, name))
  return `characters/${name}`
}

/**
 * Copies a picked image into app storage for use inside a document.
 * Images live as files rather than base64 in the row: the database stays small,
 * backups stay quick, and the same asset protocol serves them as covers.
 */
export async function importDocImage(): Promise<string | null> {
  const result = await dialog.showOpenDialog({
    title: 'Insert an image',
    properties: ['openFile'],
    filters: [{ name: 'Images', extensions: ['png', 'jpg', 'jpeg', 'webp', 'gif'] }]
  })
  if (result.canceled || result.filePaths.length === 0) return null

  const src = result.filePaths[0]
  const dir = join(assetsRoot(), 'doc-images')
  mkdirSync(dir, { recursive: true })
  const ext = extname(src).toLowerCase() || '.png'
  const name = `${randomUUID()}${ext}`
  copyFileSync(src, join(dir, name))
  return `doc-images/${name}`
}
